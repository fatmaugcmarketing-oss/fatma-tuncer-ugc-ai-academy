'use strict';
const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('#menu');
if (menuButton && menu) {
  menu.dataset.enhanced = 'true';
  const closeMenu = () => {
    menu.classList.remove('is-open');
    menuButton.setAttribute('aria-expanded', 'false');
  };
  menuButton.addEventListener('click', () => {
    const open = menu.classList.toggle('is-open');
    menuButton.setAttribute('aria-expanded', String(open));
  });
  menu.addEventListener('click', (event) => {
    if (event.target.closest('a')) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menu.classList.contains('is-open')) {
      closeMenu();
      menuButton.focus();
    }
  });
  window.matchMedia('(min-width: 901px)').addEventListener('change', closeMenu);
}

const galleryDialog = document.querySelector('.gallery-dialog');
if (galleryDialog && typeof galleryDialog.showModal === 'function') {
  let galleryTrigger;
  document.querySelectorAll('.gallery-open').forEach(link => {
    link.addEventListener('click', event => {
      event.preventDefault();
      galleryTrigger = link;
      const img = galleryDialog.querySelector('img');
      img.src = link.getAttribute('href');
      img.alt = link.querySelector('img').alt;
      galleryDialog.querySelector('figcaption').textContent = link.dataset.title;
      galleryDialog.showModal();
      document.body.classList.add('gallery-active');
    });
  });
  galleryDialog.querySelector('.gallery-close').addEventListener('click', () => galleryDialog.close());
  galleryDialog.addEventListener('click', event => {
    if (event.target === galleryDialog) {
      const rect = galleryDialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) galleryDialog.close();
    }
  });
  galleryDialog.addEventListener('close', () => {
    document.body.classList.remove('gallery-active');
    galleryTrigger?.focus();
  });
}
